import React,{useEffect,useState} from 'react';
import {supabase} from './lib/supabase';

type Activity={id:string,title:string,description:string|null,activity_type:string,starts_at:string,ends_at:string,location:string|null,capacity:number|null,is_published:boolean,speaker_id:string|null};
const empty={id:'',title:'',description:'',activity_type:'palestra',starts_at:'',ends_at:'',location:'',capacity:'',is_published:false,speaker_id:''};
const kinds=[['palestra','Palestra'],['oficina','Oficina'],['mesa-redonda','Mesa-redonda'],['outro','Outro']];
function localDate(iso:string){if(!iso)return '';const d=new Date(iso);return new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Rio_Branco',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d).replace(' ','T')}
function toIso(local:string){return new Date(local+':00-05:00').toISOString()}
export default function ProgramacaoAdmin({isOwner}:{isOwner:boolean}){
 const [rights,setRights]=useState<Record<string,boolean>>({}),[items,setItems]=useState<Activity[]>([]),[speakers,setSpeakers]=useState<{id:string,name:string}[]>([]),[form,setForm]=useState({...empty}),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[message,setMessage]=useState('');
 const can=(action:string)=>isOwner||!!rights['programacao.'+action];
 const [newSpeakerName,setNewSpeakerName]=useState('');
 const [speakerMessage,setSpeakerMessage]=useState('');
 const canCreateSpeaker=isOwner||!!rights['palestrantes.criar'];
 async function addSpeaker() {
  if(busy||!canCreateSpeaker)return;
  const name=newSpeakerName.trim();
  if(!name){setSpeakerMessage('Digite o nome do palestrante.');return}
  setBusy(true);
  setSpeakerMessage('');
  try {
   const {data,error}=await supabase.from('speakers').insert({name}).select('id,name').single();
   if(error)throw error;
   setSpeakers(current=>[...current,data].sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')));
   setForm(current=>({...current,speaker_id:data.id}));
   setNewSpeakerName('');
   setSpeakerMessage('Palestrante cadastrado e selecionado.');
  } catch(err) {
   setSpeakerMessage('Não foi possível cadastrar o palestrante: '+(err as {message:string}).message);
  } finally {
   setBusy(false);
  }
 }
 async function load(){const [{data,error},{data:people}]=await Promise.all([supabase.from('activities').select('id,title,description,activity_type,starts_at,ends_at,location,capacity,is_published,speaker_id').order('starts_at',{ascending:true}),supabase.from('speakers').select('id,name').order('name')]);if(error)setMessage('Erro ao carregar programação: '+error.message);else setItems(data||[]);setSpeakers(people||[])}
 useEffect(()=>{(async()=>{const keys=['programacao.visualizar','programacao.criar','programacao.editar','programacao.excluir','programacao.publicar','palestrantes.criar'];const entries=await Promise.all(keys.map(async k=>{const {data}=await supabase.rpc('seacom_can',{p_permission:k});return [k,!!data] as const}));setRights(Object.fromEntries(entries));await load();setLoading(false)})()},[]);
 async function save(e:React.FormEvent){e.preventDefault();if(busy||!can(form.id?'editar':'criar'))return;setMessage('');if(!form.title.trim()||!form.starts_at||!form.ends_at){setMessage('Preencha título, início e término.');return}if(new Date(form.ends_at)<=new Date(form.starts_at)){setMessage('O término precisa ser posterior ao início.');return}if(form.is_published&&!can('publicar')){setMessage('Você não tem permissão para publicar atividades.');return}setBusy(true);try{const payload={title:form.title.trim(),description:form.description.trim()||null,activity_type:form.activity_type,starts_at:toIso(form.starts_at),ends_at:toIso(form.ends_at),location:form.location.trim()||null,capacity:form.capacity===''?null:Number(form.capacity),speaker_id:form.speaker_id||null,is_published:form.is_published};const {error}=form.id?await supabase.from('activities').update(payload).eq('id',form.id):await supabase.from('activities').insert(payload);if(error)throw error;setForm({...empty});setNewSpeakerName('');setSpeakerMessage('');await load();setMessage('Atividade salva com sucesso.');window.dispatchEvent(new Event('seacom:content-updated'))}catch(err:any){setMessage('Não foi possível salvar: '+err.message)}finally{setBusy(false)}}
 async function remove(id:string){
  if(busy||!can('excluir')||!window.confirm('Excluir esta atividade? Atividades com inscrições vinculadas serão preservadas.'))return;
  setBusy(true);setMessage('');
  try{const {data,error}=await supabase.from('activities').delete().eq('id',id).select('id');
   if(error){if(error.code==='23503'){setMessage('Esta atividade possui inscrições ou outros registros vinculados e não pode ser excluída. Para ocultá-la do site sem perder os registros, use Retirar da programação. Se já estiver como Rascunho, ela já está oculta.');return}throw error}
   if(!data?.length)throw Error('Nenhuma atividade foi excluída. Verifique sua permissão e atualize a lista.');
   if(form.id===id)setForm({...empty});await load();setMessage('Atividade excluída.');window.dispatchEvent(new Event('seacom:content-updated'));
  }catch(err:any){setMessage('Não foi possível excluir: '+err.message)}finally{setBusy(false)}
 }
 async function unpublish(item:Activity){
  if(busy||!can('editar')||!window.confirm('Retirar “'+item.title+'” da programação pública? As inscrições e presenças serão preservadas. A confirmação de novas presenças ficará indisponível enquanto a atividade estiver oculta.'))return;
  setBusy(true);setMessage('');
  try{const {data,error}=await supabase.from('activities').update({is_published:false}).eq('id',item.id).select('id');if(error)throw error;if(!data?.length)throw Error('Verifique sua permissão para editar a atividade.');
   if(form.id===item.id)setForm(old=>({...old,is_published:false}));await load();setMessage('Atividade retirada da programação pública. Inscrições e presenças existentes foram preservadas.');window.dispatchEvent(new Event('seacom:content-updated'));
  }catch(err:any){setMessage('Não foi possível retirar a atividade: '+err.message)}finally{setBusy(false)}
 }
 const field='w-full border border-slate-300 rounded-lg p-2';
 if(loading)return <p>Carregando programação...</p>;
 if(!can('visualizar')&&!can('criar')&&!can('editar'))return <p className="rounded-xl bg-slate-50 p-4">Você não tem permissão para gerenciar a programação.</p>;
 return <section className="space-y-5"><h2 className="text-xl font-bold">Criar programação</h2><p className="text-sm text-slate-600">Cadastre palestras, oficinas e outras atividades. Apenas as atividades publicadas aparecem no site.</p>{message&&<p role="status" className="rounded-lg bg-indigo-50 p-3 text-sm">{message}</p>}
 {(can('criar')||can('editar'))&&<form onSubmit={save} className="space-y-3 rounded-xl border p-4"><h3 className="font-semibold">{form.id?'Editar atividade':'Nova atividade'}</h3><label className="block text-sm">Título *<input required className={field} value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label><label className="block text-sm">Descrição<textarea rows={3} className={field} value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><div className="grid gap-3 sm:grid-cols-2"><label className="block text-sm">Tipo de atividade<select className={field} value={form.activity_type} onChange={e=>setForm({...form,activity_type:e.target.value})}>{kinds.map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></label><div><label className="block text-sm">Palestrante (opcional)<select className={field} value={form.speaker_id} onChange={e=>setForm({...form,speaker_id:e.target.value})}><option value="">Não informado</option>{speakers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
 {canCreateSpeaker&&<div className="mt-2 space-y-2">
  <label className="block text-sm">Nome do novo palestrante
   <input className={field} value={newSpeakerName} disabled={busy}
    onChange={e=>{setNewSpeakerName(e.target.value);setSpeakerMessage('')}}
    onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();void addSpeaker()}}}/>
  </label>
  <button type="button" className="rounded-lg border px-3 py-2 text-sm disabled:opacity-50"
   disabled={busy||!newSpeakerName.trim()} onClick={addSpeaker}>Adicionar palestrante</button>
  {speakerMessage&&<p role="status" className="text-sm">{speakerMessage}</p>}
 </div>}
 </div><label className="block text-sm">Início * (horário do Acre)<input required type="datetime-local" className={field} value={form.starts_at} onChange={e=>setForm({...form,starts_at:e.target.value})}/></label><label className="block text-sm">Término * (horário do Acre)<input required type="datetime-local" className={field} value={form.ends_at} onChange={e=>setForm({...form,ends_at:e.target.value})}/></label><label className="block text-sm">Local<input className={field} value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></label><label className="block text-sm">Quantidade de vagas (opcional)<input type="number" min="1" step="1" className={field} value={form.capacity} onChange={e=>setForm({...form,capacity:e.target.value})}/></label></div><label className="flex items-center gap-2 text-sm"><input type="checkbox" disabled={!can('publicar')} checked={form.is_published} onChange={e=>setForm({...form,is_published:e.target.checked})}/> Publicar na programação do site</label><div className="flex flex-wrap gap-2"><button className="rounded-lg bg-indigo-700 px-4 py-2 text-white disabled:opacity-50" disabled={busy}>{busy?'Salvando...':'Salvar atividade'}</button>{form.id&&<button type="button" className="rounded-lg border px-4 py-2" disabled={busy} onClick={()=>{setForm({...empty});setNewSpeakerName('');setSpeakerMessage('')}}>Cancelar edição</button>}</div></form>}
 <div className="space-y-2"><h3 className="font-semibold">Atividades cadastradas ({items.length})</h3>{items.length===0&&<p className="text-sm text-slate-600">Nenhuma atividade cadastrada.</p>}{items.map(item=><article key={item.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3"><div><strong>{item.title}</strong><p className="text-sm text-slate-600">{localDate(item.starts_at).replace('T',' ')} · {item.location||'Local a definir'} · {item.is_published?'Publicada':'Rascunho'}</p></div><div className="flex gap-2">{can('editar')&&<button type="button" className="rounded-lg border px-3 py-2" disabled={busy} onClick={()=>{setNewSpeakerName('');setSpeakerMessage('');setForm({id:item.id,title:item.title,description:item.description||'',activity_type:item.activity_type,starts_at:localDate(item.starts_at),ends_at:localDate(item.ends_at),location:item.location||'',capacity:item.capacity==null?'':String(item.capacity),is_published:item.is_published,speaker_id:item.speaker_id||''});window.scrollTo({top:0,behavior:'smooth'})}}>Editar</button>}{can('editar')&&item.is_published&&<button type="button" disabled={busy} className="rounded-lg border px-3 py-2" onClick={()=>unpublish(item)}>Retirar da programação</button>}{can('excluir')&&<button type="button" disabled={busy} className="rounded-lg border border-red-300 px-3 py-2 text-red-700" onClick={()=>remove(item.id)}>Excluir</button>}</div></article>)}</div></section>
}
